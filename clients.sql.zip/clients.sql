-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2024 at 01:51 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clients`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `email`, `phone`, `address`, `password`, `created_at`) VALUES
(2, 'Paula Seron', 'paulaseron@gmail.com', '+69453772666', 'Imus, Cavite', '$2y$10$a4MFZEjOmcT.cEZwrmmbd.thLTkX.mNfA5Cp.lIDTd.wZe8WVmdyu', '2024-05-26 20:51:42'),
(3, 'Keithlene Galingana', 'keithlenegalingana@gmail.com', '+69453772666', 'GMA, Cavite', '$2y$10$a4MFZEjOmcT.cEZwrmmbd.thLTkX.mNfA5Cp.lIDTd.wZe8WVmdyu', '2024-05-26 20:51:42'),
(4, 'Jericho Ivan Frias', 'ivanfrias@gmail.com', '+69453772666', 'Dasmarinas, Cavite', '$2y$10$a4MFZEjOmcT.cEZwrmmbd.thLTkX.mNfA5Cp.lIDTd.wZe8WVmdyu', '2024-05-26 20:51:42'),
(5, 'Rovic Angelo Ditan', 'rovicditan@gmail.com', '+69453772666', 'Imus, Cavite', '$2y$10$a4MFZEjOmcT.cEZwrmmbd.thLTkX.mNfA5Cp.lIDTd.wZe8WVmdyu', '2024-05-26 20:51:42'),
(6, 'Carlo Luis Salcedo', 'carlosalcedo@gmail.com', '+69453772666', 'Bulihan, Cavite', '$2y$10$a4MFZEjOmcT.cEZwrmmbd.thLTkX.mNfA5Cp.lIDTd.wZe8WVmdyu', '2024-05-26 20:51:42'),
(9, 'Janna Fuselero', 'jannafuselero@gmail.com', '09453772666', 'Silang, Cavite', '$2y$10$RgnBfvPFeC31kjfvWK8AQeVnKw0jWaH1EnxBO5kUUmffQ.nwZfiKa', '2024-05-29 18:47:08'),
(11, 'Ingle De Leon', 'ingle@gmail.com', '+69453772666', 'GMA, Cavite', '$2y$10$a4MFZEjOmcT.cEZwrmmbd.thLTkX.mNfA5Cp.lIDTd.wZe8WVmdyu', '2024-05-29 18:56:58'),
(12, 'Primo Gabriel Fuselero', 'sakitsaulo@gmail.com', '09453772666', 'Silang, Cavite', '', '2024-05-29 19:09:54'),
(13, 'Bojack Horseman', 'bojack@gmail.com', '+69453772666', 'California, USA', '', '2024-05-29 19:13:46'),
(14, 'Sarah Lynn', 'sarah@gmail.com', '+69453772666', 'Texas, USA', '', '2024-05-29 19:19:57'),
(15, 'Gojo Satoru', 'fuckgege@gmail.com', '+69453772666', 'Shibuya, Japan', '$2y$10$X8V5ZU8nW3Og/iXjuu/flOgextU2Sfoq14TCj2QCzxQzdFqtEB6SO', '2024-05-29 19:21:12'),
(16, 'Janna Kibou', 'kibou@gmail.com', '+69453772666', 'Silang, Cavite', '', '2024-05-29 19:24:20'),
(17, 'test1', 'test', '123', 'asd', '', '2024-05-29 19:33:53'),
(18, 'Test User ', 'user1@gmail.com', '09453772666', 'Silang, Cavite', '', '2024-05-29 19:37:26'),
(19, 'Second User', 'second@gmail.com', '+69453772666', 'Silang, Cavite', '', '2024-05-29 19:38:25'),
(20, 'Lord Please', 'pleaselord@gmail.com', '+69453772666', 'Silang, Cavite', '$2y$10$383H51o1OL2sSJl9JqyOLebIcfuleXeYzu.2ECDFW9PZUdwNaLkNa', '2024-05-29 19:44:37'),
(21, 'Lord Thank You', 'thankyoulord@gmail.com', '+69453772666', 'Sila', '$2y$10$8sJNqpd2yqiC/C9HPYknE.bbe4lXiHNplrUHWuHSAiDB1ag/x6i86', '2024-05-29 19:45:14'),
(22, 'Lord Thank You', 'thankyoupo@gmail.com', '+69453772666', 'Shibuya, Japan', '$2y$10$.e8J5YfxigzrWMiBrTIvp.8HDSe6uQsdrpVGHWItJqzygDnxLIw8q', '2024-05-29 19:45:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
